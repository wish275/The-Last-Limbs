import pygame
import sys

pygame.init()

# Screen setup
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Last Legs: Sacrifices Must Be Made")

# Colors
BG_COLOR = (245, 245, 255)
TEXT_COLOR = (50, 50, 80)
GATE_COLOR = (255, 100, 100)
PLATFORM_COLOR = (180, 220, 255)
GOAL_COLOR = (100, 255, 100)

# Clock
clock = pygame.time.Clock()
FPS = 60

# Game state
level = 1
velocity_y = 0
gravity = 0.5
on_ground = False
jumps_left = 15

# Stickman setup
player = pygame.Rect(100, 500, 20, 60)
limbs = {
    'left_arm': 3,
    'right_arm': 3,
    'left_leg': 3,
    'right_leg': 3
}

# Platform generator
def generate_platforms(level):
    count = {1: 6, 2: 7, 3: 8, 4: 9}[level]
    spacing_x = {1: 150, 2: 180, 3: 160, 4: 140}[level]
    start_y = 500
    step_y = -40
    return [pygame.Rect(100 + i * spacing_x, start_y + i * step_y, 120, 20) for i in range(count)]

platforms = {lvl: generate_platforms(lvl) for lvl in range(1, 5)}

# Sacrifice gates
original_gates = {
    2: [pygame.Rect(400, 420, 30, 30)],
    3: [pygame.Rect(500, 350, 30, 30), pygame.Rect(650, 280, 30, 30)],
    4: [pygame.Rect(300, 500, 30, 30), pygame.Rect(500, 400, 30, 30), pygame.Rect(700, 300, 30, 30)],
}
sacrifice_gates = {}

goal = pygame.Rect(0, 0, 0, 0)

def update_goal():
    global goal
    last_platform = platforms[level][-1]
    goal = pygame.Rect(last_platform.x + 50, last_platform.y - 80, 120, 100)
    sensory_platform = pygame.Rect(goal.x + 20, goal.y + goal.height, 80, 20)
    platforms[level].append(sensory_platform)

def restart_game():
    global level, limbs, jumps_left, velocity_y
    level = 1
    limbs = {k: 3 for k in limbs}
    jumps_left = 15
    velocity_y = 0
    start_level()
    fade_transition()

def wait_for_restart():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                restart_game()
                return

def show_start_screen():
    font = pygame.font.SysFont("comicsansms", 48)
    screen.fill(BG_COLOR)
    msg = font.render("Are you ready?", True, TEXT_COLOR)
    screen.blit(msg, (WIDTH//2 - msg.get_width()//2, HEIGHT//2 - 60))
    btn = font.render("Press Y to begin", True, TEXT_COLOR)
    screen.blit(btn, (WIDTH//2 - btn.get_width()//2, HEIGHT//2 + 10))
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_y:
                show_instructions_screen()
                return

def show_instructions_screen():
    font = pygame.font.SysFont("comicsansms", 32)
    screen.fill(BG_COLOR)
    lines = [
        "Instructions:",
        "- Arrow keys to move left/right",
        "- Space to jump (limited jumps)",
        "- Collide with red squares to sacrifice limbs",
        "- Sacrifice arms or legs to progress",
        "- Reach the green goal to win the level"
    ]
    for i, line in enumerate(lines):
        text = font.render(line, True, TEXT_COLOR)
        screen.blit(text, (50, 100 + i * 40))
    prompt = font.render("Press SPACE to start Level 1", True, TEXT_COLOR)
    screen.blit(prompt, (WIDTH//2 - prompt.get_width()//2, HEIGHT - 80))
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                return

def draw_stickman(surface, x, y, limbs):
    pygame.draw.circle(surface, (0, 0, 0), (x, y), 10)
    pygame.draw.line(surface, (0, 0, 0), (x, y + 10), (x, y + 40), 2)
    if limbs['left_arm'] > 0:
        pygame.draw.line(surface, (0, 0, 0), (x, y + 20), (x - 5 * limbs['left_arm'], y + 30), 2)
    if limbs['right_arm'] > 0:
        pygame.draw.line(surface, (0, 0, 0), (x, y + 20), (x + 5 * limbs['right_arm'], y + 30), 2)
    if limbs['left_leg'] > 0:
        pygame.draw.line(surface, (0, 0, 0), (x, y + 40), (x - 3 * limbs['left_leg'], y + 60), 2)
    if limbs['right_leg'] > 0:
        pygame.draw.line(surface, (0, 0, 0), (x, y + 40), (x + 3 * limbs['right_leg'], y + 60), 2)

def fade_transition():
    fade = pygame.Surface((WIDTH, HEIGHT))
    fade.fill(BG_COLOR)
    draw_game()
    for alpha in range(0, 255, 15):
        fade.set_alpha(alpha)
        screen.blit(fade, (0, 0))
        pygame.display.update()
        pygame.time.delay(30)

def start_level():
    global player, velocity_y, jumps_left, sacrifice_gates
    player.x = 100
    player.y = 400
    velocity_y = 0
    jumps_left = {1: 15, 2: 10, 3: 5, 4: 0}[level]
    sacrifice_gates[level] = [gate.copy() for gate in original_gates.get(level, [])]
    update_goal()

def draw_game():
    screen.fill(BG_COLOR)
    draw_stickman(screen, player.centerx, player.top + 10, limbs)
    for plat in platforms[level]:
        pygame.draw.rect(screen, PLATFORM_COLOR, plat)
    for gate in sacrifice_gates.get(level, []):
        pygame.draw.rect(screen, GATE_COLOR, gate)
    pygame.draw.rect(screen, GOAL_COLOR, goal)
    font = pygame.font.SysFont(None, 24)
    info = font.render(f"Level: {level} | Jumps Left: {jumps_left} | Limb Segments Left: {sum(limbs.values())}", True, TEXT_COLOR)
    screen.blit(info, (10, 10))
    pygame.display.update()

def check_collision():
    global on_ground, velocity_y
    on_ground = False
    for plat in platforms[level]:
        if player.colliderect(plat) and player.bottom <= plat.bottom:
            player.bottom = plat.top
            velocity_y = 0
            on_ground = True
            break

def check_sacrifice_gate():
    for gate in sacrifice_gates.get(level, []):
        if player.colliderect(gate):
            show_sacrifice_prompt()
            sacrifice_gates[level].remove(gate)

def show_sacrifice_prompt():
    font = pygame.font.SysFont("comicsansms", 36)
    screen.fill(BG_COLOR)
    msg = font.render("Sacrifice a limb to proceed", True, TEXT_COLOR)
    screen.blit(msg, (WIDTH//2 - msg.get_width()//2, HEIGHT//2 - 60))
    options = font.render("Press L for leg, A for arm", True, TEXT_COLOR)
    screen.blit(options, (WIDTH//2 - options.get_width()//2, HEIGHT//2))
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_l:
                    for limb in ['left_leg', 'right_leg']:
                        if limbs[limb] > 0:
                            limbs[limb] -= 1
                            return
                elif event.key == pygame.K_a:
                    for limb in ['left_arm', 'right_arm']:
                        if limbs[limb] > 0:
                            limbs[limb] -= 1
                            return

def check_win():
    global level
    if player.colliderect(goal):
        if level < 4:
            level += 1
            start_level()
            fade_transition()
        else:
            draw_win_screen()

def check_game_over():
    if sum(limbs.values()) == 0 or player.y > HEIGHT or (jumps_left <= 0 and level < 4):
        draw_game_over_screen()

def draw_win_screen():
    screen.fill(BG_COLOR)
    font = pygame.font.SysFont("comicsansms", 60)
    msg = font.render("You made it to the end!", True, TEXT_COLOR)
    screen.blit(msg, (WIDTH//2 - msg.get_width()//2, HEIGHT//2 - 60))
    prompt = font.render("Press R to restart", True, TEXT_COLOR)
    screen.blit(prompt, (WIDTH//2 - prompt.get_width()//2, HEIGHT//2 + 10))
    pygame.display.update()
    wait_for_restart()

def draw_game_over_screen():
    screen.fill(BG_COLOR)
    font = pygame.font.SysFont("comicsansms", 60)
    msg = font.render("Game Over!", True, GATE_COLOR)
    screen.blit(msg, (WIDTH//2 - msg.get_width()//2, HEIGHT//2 - 60))
    prompt = font.render("Press R to restart", True, TEXT_COLOR)
    screen.blit(prompt, (WIDTH//2 - prompt.get_width()//2, HEIGHT//2 + 10))
    pygame.display.update()
    wait_for_restart()

# 🚀 Start the game
show_start_screen()
start_level()

# 🎮 Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and jumps_left > 0:
                velocity_y = -10
                jumps_left -= 1

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.x -= 5
    if keys[pygame.K_RIGHT]:
        player.x += 5

    velocity_y += gravity
    player.y += velocity_y

    check_collision()
    check_sacrifice_gate()
    check_win()
    check_game_over()
    draw_game()
    clock.tick(FPS)
